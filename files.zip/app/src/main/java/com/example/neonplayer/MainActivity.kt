package com.example.neonplayer

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var btnPlay: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var seekBar: SeekBar
    private lateinit var txtCurrentTime: TextView
    private lateinit var txtTotalTime: TextView
    private lateinit var txtTitle: TextView
    private lateinit var txtArtist: TextView
    private lateinit var imgAlbum: ImageView
    private lateinit var glowView: View

    private val handler = Handler(Looper.getMainLooper())
    private val updateRunnable = object : Runnable {
        override fun run() {
            updateSeekBar()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPlay = findViewById(R.id.btnPlay)
        btnNext = findViewById(R.id.btnNext)
        btnPrev = findViewById(R.id.btnPrev)
        seekBar = findViewById(R.id.seekBar)
        txtCurrentTime = findViewById(R.id.txtCurrentTime)
        txtTotalTime = findViewById(R.id.txtTotalTime)
        txtTitle = findViewById(R.id.txtTitle)
        txtArtist = findViewById(R.id.txtArtist)
        imgAlbum = findViewById(R.id.imgAlbum)
        glowView = findViewById(R.id.glowView)

        setupNeonPulse()

        // Initialize player
        player = ExoPlayer.Builder(this).build()

        // Sample playlist (public mp3s). Replace with your own URIs or local files.
        val urls = listOf(
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3"
        )

        val mediaItems = urls.map { MediaItem.fromUri(it) }
        player.setMediaItems(mediaItems)
        player.prepare()
        player.playWhenReady = false

        // update metadata display on track change
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // simple metadata placeholders; real apps would extract tags
                txtTitle.text = "Track ${player.currentMediaItemIndex + 1}"
                txtArtist.text = "Artist"
                // optionally change album art placeholder
                imgAlbum.setImageResource(android.R.drawable.ic_media_play)
                updateSeekBar()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePlayButton()
            }
        })

        btnPlay.setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
            updatePlayButton()
        }

        btnNext.setOnClickListener {
            if (player.hasNextMediaItem()) player.seekToNextMediaItem()
        }

        btnPrev.setOnClickListener {
            if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
            else player.seekTo(0)
        }

        seekBar.max = 1000
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val duration = player.duration
                    if (duration > 0) {
                        val newPos = (progress / 1000.0 * duration).toLong()
                        player.seekTo(newPos)
                    }
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun updatePlayButton() {
        runOnUiThread {
            val drawable = if (player.isPlaying) R.drawable.ic_pause else R.drawable.ic_play
            btnPlay.setImageResource(drawable)
        }
    }

    private fun updateSeekBar() {
        val position = player.currentPosition
        val duration = player.duration.takeIf { it > 0 } ?: 0L

        runOnUiThread {
            if (duration > 0) {
                val progress = (position * 1000 / duration).toInt()
                seekBar.progress = progress
                txtTotalTime.text = formatTime(duration)
            } else {
                seekBar.progress = 0
                txtTotalTime.text = "0:00"
            }
            txtCurrentTime.text = formatTime(position)
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = TimeUnit.MILLISECONDS.toSeconds(ms)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%d:%02d", minutes, seconds)
    }

    private fun setupNeonPulse() {
        // pulse the glow view scale & alpha to simulate neon breathing
        val scaleX = ObjectAnimator.ofFloat(glowView, "scaleX", 1f, 1.18f, 1f)
        val scaleY = ObjectAnimator.ofFloat(glowView, "scaleY", 1f, 1.18f, 1f)
        val alpha = ObjectAnimator.ofFloat(glowView, "alpha", 0.9f, 0.5f, 0.9f)
        val set = AnimatorSet()
        set.playTogether(scaleX, scaleY, alpha)
        set.duration = 1600
        set.startDelay = 200
        set.start()
        set.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                animation.start()
            }
        })
    }

    override fun onStart() {
        super.onStart()
        handler.post(updateRunnable)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(updateRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        player.release()
    }
}